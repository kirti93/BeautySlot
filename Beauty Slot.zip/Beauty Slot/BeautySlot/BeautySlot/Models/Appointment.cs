﻿namespace BeautySlot.Models
{
    public class Appointment
    {
        public int AppointmentId { get; set; }
        public int UserId { get; set; }
        public int TimeSlotId { get; set; }
        public string Type { get; set; }
        public string Comment { get; set; }
        public virtual User User { get; set; }
        public virtual TimeSlot TimeSlot { get; set; }
    }
}
