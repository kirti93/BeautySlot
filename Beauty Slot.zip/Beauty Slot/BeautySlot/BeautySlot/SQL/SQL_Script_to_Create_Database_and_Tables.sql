﻿-- Create database
CREATE DATABASE BeautySlot;
GO

-- Use BeautySlot database
USE BeautySlot;
GO

-- Create table for Appointment
CREATE TABLE Appointments (
    AppointmentId INT PRIMARY KEY IDENTITY,
    UserId INT FOREIGN KEY REFERENCES Users(UserId),
    TimeSlotId INT FOREIGN KEY REFERENCES TimeSlots(TimeSlotId),
    Type NVARCHAR(50),
    Comment NVARCHAR(500)
);
GO

-- Create table for TimeSlot
CREATE TABLE TimeSlots (
    TimeSlotId INT PRIMARY KEY IDENTITY,
    StartTime TIME,
    EndTime TIME
);
GO

-- Create table for User
CREATE TABLE Users (
    UserId INT PRIMARY KEY IDENTITY,
    FirstName NVARCHAR(100),
    LastName NVARCHAR(100),
    PhoneNumber NVARCHAR(20),
    Email NVARCHAR(100),
    Comments NVARCHAR(MAX)
);
GO

-- Create table for UserAddress
CREATE TABLE UserAddresses (
    AddressId INT PRIMARY KEY IDENTITY,
    UserId INT FOREIGN KEY REFERENCES Users(UserId),
    AddressLine1 NVARCHAR(200),
    AddressLine2 NVARCHAR(200),
    City NVARCHAR(100),
    State NVARCHAR(100),
    ZipCode NVARCHAR(20)
);
GO
