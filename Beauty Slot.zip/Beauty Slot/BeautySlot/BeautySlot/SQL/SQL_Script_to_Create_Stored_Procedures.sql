﻿--Appointments CRUD Stored Procedure--

CREATE PROCEDURE Appointments_CRUD
    @Operation VARCHAR(10),   -- 'CREATE', 'READ', 'UPDATE', 'DELETE'
    @AppointmentId INT = NULL,
    @UserId INT = NULL,
    @TimeSlotId INT = NULL,
    @Type NVARCHAR(50) = NULL,
    @Comment NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Operation = 'CREATE'
    BEGIN
        INSERT INTO Appointments (UserId, TimeSlotId, Type, Comment)
        VALUES (@UserId, @TimeSlotId, @Type, @Comment);
    END

    ELSE IF @Operation = 'READ'
    BEGIN
        SELECT 
            A.AppointmentId,
            A.UserId,
            A.TimeSlotId,
            A.Type,
            A.Comment,
            U.FirstName,
            U.LastName,
            TS.StartTime,
            TS.EndTime
        FROM 
            Appointments A
            INNER JOIN Users U ON A.UserId = U.UserId
            INNER JOIN TimeSlots TS ON A.TimeSlotId = TS.TimeSlotId;
        -- Add WHERE clauses or paging logic as needed
    END

    ELSE IF @Operation = 'UPDATE'
    BEGIN
        UPDATE Appointments
        SET 
            UserId = @UserId,
            TimeSlotId = @TimeSlotId,
            Type = @Type,
            Comment = @Comment
        WHERE 
            AppointmentId = @AppointmentId;
    END

    ELSE IF @Operation = 'DELETE'
    BEGIN
        DELETE FROM Appointments
        WHERE AppointmentId = @AppointmentId;
    END
END
GO
---TimeSlots CRUD Stored Procedure---
CREATE PROCEDURE TimeSlots_CRUD
    @Operation VARCHAR(10),
    @TimeSlotId INT = NULL,
    @StartTime TIME = NULL,
    @EndTime TIME = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Operation = 'CREATE'
    BEGIN
        INSERT INTO TimeSlots (StartTime, EndTime)
        VALUES (@StartTime, @EndTime);
    END

    ELSE IF @Operation = 'READ'
    BEGIN
        SELECT *
        FROM TimeSlots;
        -- Add WHERE clauses or paging logic as needed
    END

    ELSE IF @Operation = 'UPDATE'
    BEGIN
        UPDATE TimeSlots
        SET 
            StartTime = @StartTime,
            EndTime = @EndTime
        WHERE 
            TimeSlotId = @TimeSlotId;
    END

    ELSE IF @Operation = 'DELETE'
    BEGIN
        DELETE FROM TimeSlots
        WHERE TimeSlotId = @TimeSlotId;
    END
END
GO


---Users CRUD Stored Procedure--

CREATE PROCEDURE Users_CRUD
    @Operation VARCHAR(10),
    @UserId INT = NULL,
    @FirstName NVARCHAR(100) = NULL,
    @LastName NVARCHAR(100) = NULL,
    @PhoneNumber NVARCHAR(20) = NULL,
    @Email NVARCHAR(100) = NULL,
    @Comments NVARCHAR(MAX) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Operation = 'CREATE'
    BEGIN
        INSERT INTO Users (FirstName, LastName, PhoneNumber, Email, Comments)
        VALUES (@FirstName, @LastName, @PhoneNumber, @Email, @Comments);
    END

    ELSE IF @Operation = 'READ'
    BEGIN
        SELECT *
        FROM Users;
        -- Add WHERE clauses or paging logic as needed
    END

    ELSE IF @Operation = 'UPDATE'
    BEGIN
        UPDATE Users
        SET 
            FirstName = @FirstName,
            LastName = @LastName,
            PhoneNumber = @PhoneNumber,
            Email = @Email,
            Comments = @Comments
        WHERE 
            UserId = @UserId;
    END

    ELSE IF @Operation = 'DELETE'
    BEGIN
        DELETE FROM Users
        WHERE UserId = @UserId;
    END
END
GO
----UserAddresses CRUD Stored Procedure----
CREATE PROCEDURE UserAddresses_CRUD
    @Operation VARCHAR(10),
    @AddressId INT = NULL,
    @UserId INT = NULL,
    @AddressLine1 NVARCHAR(200) = NULL,
    @AddressLine2 NVARCHAR(200) = NULL,
    @City NVARCHAR(100) = NULL,
    @State NVARCHAR(100) = NULL,
    @ZipCode NVARCHAR(20) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF @Operation = 'CREATE'
    BEGIN
        INSERT INTO UserAddresses (UserId, AddressLine1, AddressLine2, City, State, ZipCode)
        VALUES (@UserId, @AddressLine1, @AddressLine2, @City, @State, @ZipCode);
    END

    ELSE IF @Operation = 'READ'
    BEGIN
        SELECT *
        FROM UserAddresses;
        -- Add WHERE clauses or paging logic as needed
    END

    ELSE IF @Operation = 'UPDATE'
    BEGIN
        UPDATE UserAddresses
        SET 
            UserId = @UserId,
            AddressLine1 = @AddressLine1,
            AddressLine2 = @AddressLine2,
            City = @City,
            State = @State,
            ZipCode = @ZipCode
        WHERE 
            AddressId = @AddressId;
    END

    ELSE IF @Operation = 'DELETE'
    BEGIN
        DELETE FROM UserAddresses
        WHERE AddressId = @AddressId;
    END
END
GO
